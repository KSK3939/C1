
#include <7seg_1.h>

LED_CONTROL_1 led_1[7]=
    {
        {GPIOC, GPIO_PIN_8, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_6, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_5, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOA, GPIO_PIN_12, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOA, GPIO_PIN_11, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOB, GPIO_PIN_12, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOB, GPIO_PIN_2, GPIO_PIN_SET, GPIO_PIN_RESET}
    };

void num0_1()
{
  HAL_GPIO_WritePin(led_1[0].port, led_1[0].number, led_1[0].onState);
  HAL_GPIO_WritePin(led_1[1].port, led_1[1].number, led_1[1].onState);
  HAL_GPIO_WritePin(led_1[2].port, led_1[2].number, led_1[2].onState);
  HAL_GPIO_WritePin(led_1[3].port, led_1[3].number, led_1[3].onState);
  HAL_GPIO_WritePin(led_1[4].port, led_1[4].number, led_1[4].onState);
  HAL_GPIO_WritePin(led_1[5].port, led_1[5].number, led_1[5].onState);
  HAL_GPIO_WritePin(led_1[6].port, led_1[6].number, led_1[6].offState);
}
void num1_1()
{
  HAL_GPIO_WritePin(led_1[0].port, led_1[0].number, led_1[0].offState);
  HAL_GPIO_WritePin(led_1[1].port, led_1[1].number, led_1[1].onState);
  HAL_GPIO_WritePin(led_1[2].port, led_1[2].number, led_1[2].onState);
  HAL_GPIO_WritePin(led_1[3].port, led_1[3].number, led_1[3].offState);
  HAL_GPIO_WritePin(led_1[4].port, led_1[4].number, led_1[4].offState);
  HAL_GPIO_WritePin(led_1[5].port, led_1[5].number, led_1[5].offState);
  HAL_GPIO_WritePin(led_1[6].port, led_1[6].number, led_1[6].offState);
}
void num2_1()
{
  HAL_GPIO_WritePin(led_1[0].port, led_1[0].number, led_1[0].onState);
  HAL_GPIO_WritePin(led_1[1].port, led_1[1].number, led_1[1].onState);
  HAL_GPIO_WritePin(led_1[2].port, led_1[2].number, led_1[2].offState);
  HAL_GPIO_WritePin(led_1[3].port, led_1[3].number, led_1[3].onState);
  HAL_GPIO_WritePin(led_1[4].port, led_1[4].number, led_1[4].onState);
  HAL_GPIO_WritePin(led_1[5].port, led_1[5].number, led_1[5].offState);
  HAL_GPIO_WritePin(led_1[6].port, led_1[6].number, led_1[6].onState);
}
void num3_1()
{
  HAL_GPIO_WritePin(led_1[0].port, led_1[0].number, led_1[0].onState);
  HAL_GPIO_WritePin(led_1[1].port, led_1[1].number, led_1[1].onState);
  HAL_GPIO_WritePin(led_1[2].port, led_1[2].number, led_1[2].onState);
  HAL_GPIO_WritePin(led_1[3].port, led_1[3].number, led_1[3].onState);
  HAL_GPIO_WritePin(led_1[4].port, led_1[4].number, led_1[4].offState);
  HAL_GPIO_WritePin(led_1[5].port, led_1[5].number, led_1[5].offState);
  HAL_GPIO_WritePin(led_1[6].port, led_1[6].number, led_1[6].onState);
}
StateFunc fndData_1[4] =
    {
        num0_1, num1_1, num2_1, num3_1
    };

