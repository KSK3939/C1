/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "button.h"
#include "7seg_1.h"
#include "7seg.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t rxData[10];
uint8_t speed = 0;
uint8_t mt_flag = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if(rxData[0] == 'A')
  {
    HAL_TIM_Base_Stop(&htim2);    //카운트 정지
    speed = 0;
  }
  else if(rxData[0] == 'B')
  {
    HAL_TIM_Base_Start(&htim2);   //카운트 시작
    speed = speed % 3 + 1;        // speed가 0, 1, 2, 3, 1, 2... 순으로 진행됨
  }
  else if(rxData[0] == 'C')
  {
    mt_flag ^= 1;
  }
  HAL_UART_Receive_IT(&huart1, rxData, 1);
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);   //DC모터 활성화
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);   //DC모터 활성화
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);   //Servo모터 활성화
  HAL_UART_Receive_IT(&huart1, rxData, 1);    //UART 활성화

  static uint32_t prevTime = 0;   //FND 시간표현 관련 변수
  uint16_t count = 0;             //FND 숫자

//  uint8_t speed = 0;  //DC모터 풍량 변수
  fndData_1[0]();       //7-Seg에 '0'표시

  static uint32_t prevMoveTime = 0;   //회전 관련 논블로킹 변수
//  volatile uint8_t mt_flag = 0;     //회전, 정지 기준 변수
  uint8_t pos = 100;                   //회전 초기 각도
  int8_t dir = 1;                     //회전 초기 방향(정방향)
  TIM4->CCR1 = pos;                   //첫 구동시 초기각 설정
  HAL_Delay(500);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
    uint32_t currTime = __HAL_TIM_GET_COUNTER(&htim2);
    fndDisplay(count);

    if (currTime - prevTime >= 1000000)   // 1 = 1μm, 1000000 = 1s
    {
      prevTime = currTime;
      count++;
    }
    HAL_Delay(1);

    if(buttonGetPressed(0))
    {
      HAL_TIM_Base_Stop(&htim2);    //카운트 정지
      speed = 0;
    }

    if(buttonGetPressed(1))
    {
      HAL_TIM_Base_Start(&htim2);   //카운트 시작
      speed = speed % 3 + 1;        // speed가 0, 1, 2, 3, 1, 2... 순으로 진행됨
    }

    if(speed == 0)            // 정지
    {
      fndData_1[0]();         //7-Seg에 '0'표시
      TIM3->CCR1 = 0;
      TIM3->CCR2 = 0;
    }
    else if(speed == 1)       // 1단계
    {
      fndData_1[1]();         //7-Seg에 '1'표시
      TIM3->CCR1 = 0;
      TIM3->CCR2 = 50;
    }
    else if(speed == 2)       // 2단계
    {
      fndData_1[2]();         //7-Seg에 '2'표시
      TIM3->CCR1 = 0;
      TIM3->CCR2 = 65;
    }
    else if(speed == 3)       // 3단계
    {
      fndData_1[3]();         //7-Seg에 '3'표시
      TIM3->CCR1 = 0;
      TIM3->CCR2 = 80;
    }

    if (buttonGetPressed(2)) mt_flag ^= 1;    // 0 - Off, 1 - On

    if (mt_flag)
    {
      uint32_t now = __HAL_TIM_GET_COUNTER(&htim2);

      if (now - prevMoveTime >= 100000)   // 1 = 1μm, 100000 = 100ms
      {
        prevMoveTime = now;
        TIM4->CCR1 = pos;
        pos += dir;

        if (pos >= 110) dir = -1;   //회전 역방향 설정
        if (pos <= 70)  dir = 1;    //회전 정방향 설정
      }
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
