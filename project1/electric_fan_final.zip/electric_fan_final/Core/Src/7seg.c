
#include "7seg.h"

LED_CONTROL_7 led[11]=
    {
        {GPIOC, GPIO_PIN_11, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOD, GPIO_PIN_2, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_10, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_12, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOA, GPIO_PIN_15, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOB, GPIO_PIN_7, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOA, GPIO_PIN_1, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOA, GPIO_PIN_4, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOB, GPIO_PIN_0, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_1, GPIO_PIN_SET, GPIO_PIN_RESET},
        {GPIOC, GPIO_PIN_0, GPIO_PIN_SET, GPIO_PIN_RESET}
    };

void num0()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].onState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].offState);
}
void num1()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].offState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].offState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].offState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].offState);
}
void num2()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].offState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].onState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].offState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num3()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].offState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num4()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].offState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].offState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num5()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].offState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num6()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].offState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].onState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num7()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].offState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].offState);
}
void num8()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].onState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
void num9()
{
  HAL_GPIO_WritePin(led[0].port, led[0].number, led[0].onState);
  HAL_GPIO_WritePin(led[1].port, led[1].number, led[1].onState);
  HAL_GPIO_WritePin(led[2].port, led[2].number, led[2].onState);
  HAL_GPIO_WritePin(led[3].port, led[3].number, led[3].onState);
  HAL_GPIO_WritePin(led[4].port, led[4].number, led[4].offState);
  HAL_GPIO_WritePin(led[5].port, led[5].number, led[5].onState);
  HAL_GPIO_WritePin(led[6].port, led[6].number, led[6].onState);
}
StateFunc fndData[10] =
    {
        num0, num1, num2, num3, num4,
        num5, num6, num7, num8, num9
    };

void fndDisplay(uint16_t data)
{
  static uint8_t position = 0;

  switch (position)
  {
    case 0:
      // 첫번째 자리를 출력하기 위해서는, 0번핀 LOW, 1,2,3번핀 HIGH 설정
      HAL_GPIO_WritePin(led[7].port, led[7].number, led[7].offState);
      HAL_GPIO_WritePin(led[8].port, led[8].number, led[8].onState);
      HAL_GPIO_WritePin(led[9].port, led[9].number, led[9].onState);
      HAL_GPIO_WritePin(led[10].port, led[10].number, led[10].onState);
      //입력된 데이터를 천의 자리를 구해서 해당 디지트에 값을 출력
      fndData[(data/1000)% 10]();
      break;
    case 1:
      // 두번째 자리를 출력하기 위해서는, 1번핀 LOW, 0,2,3번핀 HIGH 설정
      HAL_GPIO_WritePin(led[7].port, led[7].number, led[7].onState);
      HAL_GPIO_WritePin(led[8].port, led[8].number, led[8].offState);
      HAL_GPIO_WritePin(led[9].port, led[9].number, led[9].onState);
      HAL_GPIO_WritePin(led[10].port, led[10].number, led[10].onState);
      //입력된 데이터를 백의 자리를 구해서 해당 디지트에 값을 출력
      fndData[(data/100)%10]();  //천, 백의 자리 출력 후 천의 자리 날려버림
      break;
    case 2:
      // 세번째 자리를 출력하기 위해서는, 2번핀 LOW, 0,1,3번핀 HIGH 설정
      HAL_GPIO_WritePin(led[7].port, led[7].number, led[7].onState);
      HAL_GPIO_WritePin(led[8].port, led[8].number, led[8].onState);
      HAL_GPIO_WritePin(led[9].port, led[9].number, led[9].offState);
      HAL_GPIO_WritePin(led[10].port, led[10].number, led[10].onState);
      //입력된 데이터를 십의 자리를 구해서 해당 디지트에 값을 출력
      fndData[(data/10)%10]();
      break;
    case 3:
      // 네번째 자리를 출력하기 위해서는, 3번핀 LOW, 0,1,2번핀 HIGH 설정
      HAL_GPIO_WritePin(led[7].port, led[7].number, led[7].onState);
      HAL_GPIO_WritePin(led[8].port, led[8].number, led[8].onState);
      HAL_GPIO_WritePin(led[9].port, led[9].number, led[9].onState);
      HAL_GPIO_WritePin(led[10].port, led[10].number, led[10].offState);
      //입력된 데이터를 일의 자리를 구해서 해당 디지트에 값을 출력
      fndData[data%10]();
      break;
    default:
      break;
  }
  position++;  //다음 자리로 이동하기 위해서 포지션값을 증가
  position = position % 4;  //4자리를 출력한 후에 다시 첫번째로 돌아가야 해서 4로 나눈 나머지를 이용함
}
