
#ifndef INC_7SEG_H_
#define INC_7SEG_H_

#include "stm32f4xx_hal.h"

typedef struct
{
  GPIO_TypeDef  *port;
  uint16_t      number;
  GPIO_PinState onState;
  GPIO_PinState offState;
}LED_CONTROL_7;

void num0();
void num1();
void num2();
void num3();
void num4();
void num5();
void num6();
void num7();
void num8();
void num9();

typedef void (*StateFunc)();
extern StateFunc fndData[10];

void fndDisplay(uint16_t data);

#endif /* INC_7SEG_H_ */
