
#ifndef INC_7SEG_1_H_
#define INC_7SEG_1_H_

#include "stm32f4xx_hal.h"

typedef struct
{
  GPIO_TypeDef  *port;
  uint16_t      number;
  GPIO_PinState onState;
  GPIO_PinState offState;
}LED_CONTROL_1;

void num0_1();
void num1_1();
void num2_1();
void num3_1();

typedef void (*StateFunc)();
extern StateFunc fndData_1[4];

#endif /* INC_7SEG_1_H_ */
